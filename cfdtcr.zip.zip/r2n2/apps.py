from django.apps import AppConfig


class R2N2Config(AppConfig):
    name = 'r2n2'
