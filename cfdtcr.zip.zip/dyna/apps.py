from django.apps import AppConfig


class DynaConfig(AppConfig):
    name = 'dyna'
