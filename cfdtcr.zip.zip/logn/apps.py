from django.apps import AppConfig


class LognConfig(AppConfig):
    name = 'logn'
