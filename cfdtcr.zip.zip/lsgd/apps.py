from django.apps import AppConfig


class LsgdConfig(AppConfig):
    name = 'lsgd'
