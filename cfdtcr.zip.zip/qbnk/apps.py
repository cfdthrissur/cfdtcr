from django.apps import AppConfig


class QbnkConfig(AppConfig):
    name = 'qbnk'
